package cdx.utils.javacp.util;

public interface Cloneable {

}
